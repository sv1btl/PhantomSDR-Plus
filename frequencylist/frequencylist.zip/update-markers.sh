#!/bin/bash

#enter here the full path to your 'frequencylist' folder, don't use '~ ' if you use the cron service
cd $HOME/PhantomSDR-Plus/frequencylist/

#is the last HFCC DB downloaded?
curl https://new.hfcc.org/data/ > ./curl-output.txt
#scan the page and keep the last update at $lastUpdateLine
while IFS= read -r line; do
	if echo "$line" | grep -q "Last updated on "; then
		echo "matched --> $line";
		lastUpdateLine=$line
	fi
done < ./curl-output.txt
echo "Last Update: $lastUpdateLine"

#get the currently used release by the stored file
currentUpdateLine=$(<./currentUpdateFile.txt)

#check if a new release exist
#delete all NL, tabs and CR at booth var
lastUpdateLine=$(echo $lastUpdateLine|tr -d '\n\t\r ')
currentUpdateLine=$(echo $currentUpdateLine|tr -d '\n\t\r ')

if [[ "$lastUpdateLine" == "$currentUpdateLine" ]]; then
	echo "match --> no download needed"
else
	echo "new download needed"
	echo "old release: $currentUpdateLine"
	echo "new release: $lastUpdateLine"
	echo $lastUpdateLine > ./currentUpdateFile.txt
	rm ./*0.TXT
	rm ./*.zip
	
	#extract the zip archive name by a line like this:
	#<LI> <A HREF="b25/b25allx2.zip"> B25allx2.zip </A> - B25 Operational Schedule - .....
	zipArchive=$(echo "$lastUpdateLine"| cut -d'"' -f 2)
	url="https://new.hfcc.org/data/"
	url+=$zipArchive #https://new.hfcc.org/data/b25/b25allx2.zip
	zipArchive=$(echo "$zipArchive"| cut -d'/' -f 2) #b25allx2.zip

	#download the new release of DB
	curl $url --output ./$zipArchive
	
	#extract zip
	unzip -o $zipArchive
	
	#rename
	dbFilename=${zipArchive:0:3} #get the first 3 chars --> b25
	dbFilename=${dbFilename^^} # upper case --> B25
	dbFilename+='all00.TXT' # postfix --> B25all00.TXT
	mv $dbFilename ./0.TXT
fi

##############################################################
# Generate current shortwave stations
python3 generate-current-shortwave.py

##############################################################
# Combine all marker files using Python for proper JSON handling
python3 << 'EOF'
import json
import os

# Read all marker files
markers = []

# 1. Read striped-base-markers.json
try:
    with open('striped-base-markers.json', 'r') as f:
        base_markers = json.load(f)
        markers.extend(base_markers)
        print(f"✓ Loaded {len(base_markers)} base markers")
except FileNotFoundError:
    print("⚠ striped-base-markers.json not found, skipping")
except json.JSONDecodeError as e:
    print(f"✗ Error reading striped-base-markers.json: {e}")

# 2. Read shortwavestations.json (auto-generated)
try:
    with open('shortwavestations.json', 'r') as f:
        shortwave_markers = json.load(f)
        markers.extend(shortwave_markers)
        print(f"✓ Loaded {len(shortwave_markers)} shortwave markers")
except FileNotFoundError:
    print("⚠ shortwavestations.json not found, skipping")
except json.JSONDecodeError as e:
    print(f"✗ Error reading shortwavestations.json: {e}")

# 3. Read mymarkers.json (user's manual markers)
try:
    with open('mymarkers.json', 'r') as f:
        my_markers = json.load(f)
        markers.extend(my_markers)
        print(f"✓ Loaded {len(my_markers)} custom markers from mymarkers.json")
except FileNotFoundError:
    print("⚠ mymarkers.json not found, skipping")
except json.JSONDecodeError as e:
    print(f"✗ Error reading mymarkers.json: {e}")

# Create the final structure
output = {
    "markers": markers
}

# Write to markers.json in parent directory
try:
    with open('../markers.json', 'w') as f:
        json.dump(output, f, indent=2)
    print(f"\n✓ Successfully created markers.json with {len(markers)} total markers")
except Exception as e:
    print(f"\n✗ Error writing markers.json: {e}")
    exit(1)

EOF

echo ""
echo "Done! markers.json has been updated."
